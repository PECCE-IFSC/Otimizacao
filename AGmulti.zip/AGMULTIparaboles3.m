% paraboles3.m
 
function [result] = paraboles3(Indv)

x=Indv(1);
y=Indv(2);

F1= x.^2 + (y-1).^2;
F2= x.^2 + (y+1).^2 + 1;
F3= (x-1).^2 + y.^2 + 2;

result = [F1 F2 F3];