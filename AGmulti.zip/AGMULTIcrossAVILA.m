% Subrotine crossAVILA.m

function rpopReal = crossAVILA(rpopReal,pcross)

[nbpop,nvar]=size(rpopReal);
if rem(nbpop,2)==1 rpopReal(end+1,:)=rpopReal(end,:);nbpop=nbpop+1; end	

pai1 = rpopReal(1:(nbpop/2),:);
pai2 = rpopReal((nbpop/2+1:nbpop),:);

limalpha=[-0.1 1.1];                            
for i=1:nbpop/2
    
    B1 = rand(1);
      
    if B1 <= pcross
       
       B2 = rand(1);
       alphapol = 0.90;                         
       alpha = (limalpha(2) - limalpha(1))*B2;      
   
       Kcross = round( nvar * rand(1));         
       if Kcross==0 Kcross = 1; end
       dir = rand(1);              
       if dir >= 0.5
            for j = Kcross:nvar    
                rpopReal(i,j) = alphapol*pai1(i,j) + (1-alphapol)*pai2(i,j);    
                rpopReal(nbpop/2+i,j) = (1-alpha)*pai1(i,j) + alpha*pai2(i,j);  
             end
        else
            for j = 1:Kcross    
                rpopReal(i,j) = alphapol*pai1(i,j) + (1-alphapol)*pai2(i,j);    
                rpopReal(nbpop/2+i,j) = (1-alpha)*pai1(i,j) + alpha*pai2(i,j);  
            end
       end
        
   
   end
end


