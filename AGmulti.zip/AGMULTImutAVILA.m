% Subrotine mutAVILA.m
%

function rpopReal = AGMULTImutAVILA(rpopReal,pmut,limits,n,nbgen)

[nbpop,nvar]=size(rpopReal);
for i = 1:nvar
    lim(i) = limits(i,2)-limits(i,1);  % range
    range(i) = max(rpopReal(:,i)) - min(rpopReal(:,i));   % behavior
end
for i = 1:nbpop
      prob=rand(1);
      if prob<pmut
          Kmut = ceil( nvar * rand(1));    % cup point
          if Kmut==0 Kmut = 1; end
          Bi= rand(1);
          if n <= nbgen/4
              gama(i,:) = 0.05*Bi*lim;    % 5% maximum of range 
          else
             gama(i,:) = 0.05*Bi*range;   % 5% maximum of population behavior
          end
          dir = rand(1);                    % direction
          aux = rand(1);                    % addition or reduction of the perturbation
          if aux > 0.5 sinal = 1; else sinal = -1; end
          if dir >= 0.5
              for j = Kmut:nvar
                  rpopReal(i,j) = rpopReal(i,j) + sinal*gama(i,j);
              end
          else
              for j = 1:Kmut
                  rpopReal(i,j) = rpopReal(i,j) + sinal*gama(i,j);
              end
          end
          
      end
end





