% paraboles2.m

function [result] = paraboles2(Indv);

x=Indv(1);
y=Indv(2);
F1 = (x+1).^2+y.^2;  	  %parabole 1
F2 = (x-1).^2+y.^2; 		  %parabole 2
result=[F1 F2];




