% Subrotine clearPO.m

function [POPNDOM,AVNDOM,POPDOM,AVDOM] = AGMULTIclearPO(POPNDOM,AVNDOM,POPDOM,AVDOM,DminP,DminO)

	 [n,m]=size(POPNDOM);
    aux=size(POPDOM,1)+1;
    for i = 1:n-1
        for j = i+1:n
            if AVNDOM(j,1) ~= 1e8
                if abs(POPNDOM(i,:)-POPNDOM(j,:)) < DminP
                    if abs(AVNDOM(i,:)-AVNDOM(j,:)) < DminO
                        POPDOM(aux,:) = POPNDOM(j,:);
                        AVDOM(aux,:) = AVNDOM(j,:);
                        AVNDOM(j,1) = 1e8;
                        aux=aux+1;
                    end
                end
            end
        end
    end
    a=1;
    NDOM=[]; XAVNDOM=[];
    for x = 1:n
        if AVNDOM(x,1) ~= 1e8
            NDOM(a,:) = POPNDOM(x,:);
            XAVNDOM(a,:) = AVNDOM(x,:);
            a = a + 1;
        end
    end
    
    POPNDOM=[]; AVNDOM=[];
    POPNDOM = NDOM;
    AVNDOM = XAVNDOM;