% Multi-objective Genetic Algorithm
% version dez/2004
clc; clear all; close all;

%% data
func	 ='AGMULTIparaboles3'; 			  									% function - problem
nbobj  = 3;			      													% number of objectives
nbpop  = 100; 	         													% number of individus
nbgen  = 50; 	         													% number of generations 
pcross = 0.9;													            % crossover probability
pmut   = 0.05; 	       	   											% mutation probability
limits = [-3 3;-3 3];         											% limits of the problem
nvar   = size(limits,1);													% number of variables
conve	 = 2500;		         												% convergence - number of non-dominated
fclear = 1;																		% clearing technique - 0:off 1:on
dminp  = 0.05;																	% minimal distance in parameters space
dmino  = 0.05;																	% minimal distance in fitness space

% MGA
popInitial=rand(nbpop,nvar).*repmat((limits(:,2)-limits(:,1))',nbpop,1) + repmat(limits(:,1)',nbpop,1);
for (i=1:nbpop) [avInitial(i,:)]=feval(func,popInitial(i,:)); end % evaluation
% intial Pareto 
POPDOM=[];AVDOM=[];POPNDOM=[];AVNDOM=[];
rpopReal=popInitial; rpopAV=avInitial;
[POPDOM,POPNDOM,AVDOM,AVNDOM]=AGMULTIpareto(popInitial,avInitial,POPDOM,AVDOM,POPNDOM,AVNDOM);	% Pareto's check
% evolutionary process
for n=1:nbgen
	 if (fclear==1) [POPNDOM,AVNDOM,POPDOM,AVDOM]=AGMULTIclearPO(POPNDOM,AVNDOM,POPDOM,AVDOM,dminp,dmino); end %clearing
    % keeping all data
    %ndom=size(POPNDOM,1); dom=size(POPDOM,1);
    %POPN=[POPN; n*ones(ndom,1) POPNDOM]; POP=[POP; n*ones(dom,1) POPDOM]; 
    %AVN=[AVN;  n*ones(ndom,1) AVNDOM]; AV=[AV;  n*ones(dom,1) AVDOM];
    %a=size(rpopAV,1);
    %RPOP=[RPOP; n*ones(a,1) rpopReal];
    %RAV=[RAV;  n*ones(a,1) rpopAV];
    % convergence  
    if (size(POPNDOM,1)>=conve)
       break;
       disp('---');
    	 disp(['Generation:   ',num2str(n)]);
    	 disp(['      Number of non-dominated solutions:   ',num2str(size(POPNDOM,1))]);
    	 disp(['      Number of dominated solutions:       ',num2str(size(POPDOM,1))]);
    end
    % population complet 
    popReal=POPNDOM; popAV=AVNDOM;
    nbNDOM=size(popReal,1); nbDOM=size(POPDOM,1);
    MED=sum(popAV)/size(popAV,1);  			  % average fitness
    if nbNDOM<nbpop                			  % if the number of non-dominated solutions are smaller than nbpop, it is necessary to supplement 
       aux=nbNDOM;
       for x=1:(nbpop-nbNDOM)
           aux=aux+1;
           ind=round(nbDOM*rand(1));  if ind==0; ind=1; end
           popReal(aux,:)=POPDOM(ind,:);
           popAV(aux,:)=AVDOM(ind,:);
       end
    end
    rpopReal=[]; rpopAV=[];
    rpopReal=AGMULTITournoiAmdet(popReal,popAV,nbpop,MED);	   % selection by AMDET + TOURNOI
 	 rpopReal=AGMULTIcrossAVILA(rpopReal,pcross);					% crossover Avila
    rpopReal=AGMULTImutAVILA(rpopReal,pmut,limits,n,nbgen);		% mutation Avila
    [rnbpop,rnvar]=size(rpopReal);   									% reflection             
    for i=1:rnbpop 
     	  for j=1:rnvar
            if rpopReal(i,j)<limits(j,1) rpopReal(i,j)=limits(j,1); end        
            if rpopReal(i,j)>limits(j,2) rpopReal(i,j)=limits(j,2); end        
    	  end
    end
    for (i=1:rnbpop) [rpopAV(i,:)]=feval(func,rpopReal(i,:)); end % evaluation         
    popReal=[rpopReal ; popReal]; popAV=[rpopAV ; popAV];			% Pareto's check
    [POPDOM,POPNDOM,AVDOM,AVNDOM]=AGMULTIpareto(popReal,popAV,POPDOM,AVDOM,POPNDOM,AVNDOM);
    disp('---');
    disp(['Generation:   ',num2str(n)]);
    disp(['      Number of non-dominated solutions:   ',num2str(size(POPNDOM,1))]);
    disp(['      Number of dominated solutions:       ',num2str(size(POPDOM,1))]);
end



