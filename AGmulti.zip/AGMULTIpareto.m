% Subrotine pareto.m

function [POPDOM,POPNDOM,AVDOM,AVNDOM] = AGMULTIpareto(popReal,popAV,POPDOM,AVDOM,POPNDOM,AVNDOM)

[lin,col]=size(popAV);

POPDOMGE=[];
POPNDOMGE=[];
AVDOMGE=[];
AVNDOMGE=[];

% dominated population 
aux=1;
for x = 1:lin
    if popAV(x,:) ~= 10000
        for y = 1:lin
            if x ~= y
                if popAV(y,:) ~= 10000
                            if popAV(x,:) <= popAV(y,:) 
                                POPDOMGE(aux,:) = popReal(y,:);
                                AVDOMGE(aux,:) = popAV(y,:);
                                aux = aux+1;
                                popAV(y,:) = 10000;
                            end
                 end
                
            end
        end
    end
end
% non-dominated population
aux2=1;
for x = 1:lin
    if popAV(x,1) ~= 10000
        POPNDOMGE(aux2,:) = popReal(x,:);
        AVNDOMGE(aux2,:) = popAV(x,:);
        aux2 = aux2+1;
    end
end
POPNDOM = POPNDOMGE;
AVNDOM = AVNDOMGE;

% POPDOM (only different solutions)
a=0; b=0; AUX=[]; 
a=size(POPDOM,1);  %if a == 0 - first generation
if a ~= 0
    for i = 1:size(POPDOMGE,1)
        b=0;
        for j = 1:size(POPDOM,1)
            if POPDOMGE(i,:)==POPDOM(j,:);
                b=1;
                break;
            end
        end
        if b==0
            a=a+1;
            POPDOM(a,:)=POPDOMGE(i,:);
            AVDOM(a,:)=AVDOMGE(i,:);
        end
    end
else
    POPDOM = POPDOMGE;
    AVDOM = AVDOMGE;
end