% Subrotine selection tournoi + amdet.m

function	[rpopReal] = AGMULTITournoiAmdet(popReal,popAv,nav,MED)
rpopReal=[];
[nbpop,nvar]=size(popReal);
[nbpop,nbobj]=size(popAv);
nn=ceil(nav/(nbobj+1)); % number of different sub-population
% selection by tournoi
aux = ceil(nbpop/10);       % ten% of nbpop into the tournoi
for b=1:nn
   aux2=b;
   for i=1:nbobj
      ind1=randperm(nbpop);
      ind2=ind1(1:aux);
      av=[]; av=popAv(ind2,i);
      [a,p]=min(av);
      rpopReal(aux2,:)=popReal(ind2(p),:);
      aux2=aux2+nn;
   end
end
% selection by amdet
aux=1;rpop=[];
for i = 1:size(popReal,1)
    if popAv(i,:)<MED 
       rpop(aux,:)=popReal(i,:);
       aux=aux+1;
    end
end
nbrpop=size(rpop,1);
if nbrpop<nn
   for x=1:(nn-nbrpop)
      ind=ceil(nbpop*rand(1));
      rpop(nbrpop+x,:)=popReal(ind,:);
   end
end
if nbrpop>nn
   rrpop=rpop(1:nn,:);
   rpop=[];
   rpop=rrpop;
end
rpopReal=[rpopReal; rpop];  
